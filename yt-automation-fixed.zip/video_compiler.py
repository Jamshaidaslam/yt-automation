"""
video_compiler.py — Fast-Cut Video Engine with Cinematic Effects
AI Dark Realities · Short-Form Video Pipeline
──────────────────────────────────────────────
Upgrades:
  - Fast cuts: each clip max 2.5s before hard cut
  - Zoom-in pulse effect on each clip (slow Ken Burns zoom)
  - Flash-white transition between clips
  - Big bold captions centered mid-screen (FONT_SIZE 90)
  - Caption word highlight: current word YELLOW, previous word fades WHITE
  - Vignette darkening overlay on edges for cinematic feel
  - No mask_color crash (RGBA handled correctly)
"""

import logging
import textwrap
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from moviepy.editor import (
    VideoClip,
    VideoFileClip,
    AudioFileClip,
    CompositeVideoClip,
    concatenate_videoclips,
    ImageClip,
)
from moviepy.video.fx.all import crop, resize
import config

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")

W   = config.VIDEO_WIDTH    # 1080
H   = config.VIDEO_HEIGHT   # 1920
FPS = config.VIDEO_FPS      # 30

# ── Caption Style ─────────────────────────────────────────────────────────────
FONT_SIZE           = 90                          # Big and visible
CAPTION_Y_CENTER    = int(H * 0.62)               # Slightly below center
ACTIVE_COLOR        = (255, 230, 0,  255)         # Neon yellow — current word
STROKE_COLOR        = (0,   0,   0,  255)         # Black outline
STROKE_WIDTH        = 6

# ── Cut / Effect Settings ─────────────────────────────────────────────────────
MAX_CLIP_DURATION   = 2.5    # Seconds — max before hard cut
ZOOM_FACTOR_END     = 1.10   # End zoom for Ken Burns (10% zoom in)
FLASH_DURATION      = 0.06   # White flash transition duration in seconds


def _get_font(size: int) -> ImageFont.FreeTypeFont:
    try:
        font_name = getattr(config, "FONT_NAME", None) or "Impact.ttf"
        font_path  = config.FONTS_DIR / font_name
        if font_path.exists():
            return ImageFont.truetype(str(font_path), size)
        # Try system fonts
        for sys_font in ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                         "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
                         "/System/Library/Fonts/Impact.ttf"]:
            if Path(sys_font).exists():
                return ImageFont.truetype(sys_font, size)
        return ImageFont.load_default()
    except Exception:
        return ImageFont.load_default()


# ── Pre-build vignette overlay (created once, reused) ────────────────────────
def _make_vignette() -> np.ndarray:
    """Dark vignette edges — cinematic feel."""
    arr = np.zeros((H, W, 4), dtype=np.uint8)
    cx, cy = W / 2, H / 2
    max_d  = (cx**2 + cy**2) ** 0.5
    for y in range(H):
        for x in range(W):
            d = ((x - cx)**2 + (y - cy)**2) ** 0.5
            alpha = int(180 * (d / max_d) ** 2)
            arr[y, x] = [0, 0, 0, min(alpha, 180)]
    return arr

# Build vignette once at module load (expensive but reused)
logger.info("Pre-computing vignette overlay...")
_VIGNETTE = _make_vignette()
logger.info("Vignette ready.")


def _render_caption_frame(t: float, word_timings: list[dict]) -> np.ndarray:
    """
    Render a transparent RGBA caption overlay for time t.
    Shows current active word in neon yellow with heavy black stroke.
    """
    img  = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    active_word = ""
    for item in word_timings:
        if item["start"] <= t <= item["end"]:
            active_word = item["word"].upper()
            break

    if not active_word:
        return np.array(img)

    font = _get_font(FONT_SIZE)
    wrapped = textwrap.wrap(active_word, width=10)
    total_h = 0
    line_sizes = []
    for line in wrapped:
        bbox   = draw.textbbox((0, 0), line, font=font)
        lw, lh = bbox[2] - bbox[0], bbox[3] - bbox[1]
        line_sizes.append((lw, lh))
        total_h += lh + 20

    current_y = CAPTION_Y_CENTER - total_h // 2

    for i, line in enumerate(wrapped):
        lw, lh = line_sizes[i]
        x = (W - lw) // 2

        # 8-axis heavy stroke
        for dx, dy in [(-STROKE_WIDTH, -STROKE_WIDTH), (STROKE_WIDTH, -STROKE_WIDTH),
                       (-STROKE_WIDTH,  STROKE_WIDTH), (STROKE_WIDTH,  STROKE_WIDTH),
                       (-STROKE_WIDTH, 0), (STROKE_WIDTH, 0),
                       (0, -STROKE_WIDTH), (0, STROKE_WIDTH)]:
            draw.text((x + dx, current_y + dy), line, font=font, fill=STROKE_COLOR)

        # Main neon text
        draw.text((x, current_y), line, font=font, fill=ACTIVE_COLOR)
        current_y += lh + 20

    return np.array(img)


def _apply_zoom_effect(clip, zoom_end: float = ZOOM_FACTOR_END):
    """
    Ken Burns slow zoom-in effect over the clip's duration.
    zoom_end=1.10 means clip ends 10% zoomed in.
    """
    dur = clip.duration

    def zoom_frame(get_frame, t):
        progress = t / dur if dur > 0 else 0
        scale    = 1.0 + (zoom_end - 1.0) * progress
        frame    = get_frame(t)
        h, w     = frame.shape[:2]
        new_w    = int(w * scale)
        new_h    = int(h * scale)
        img      = Image.fromarray(frame).resize((new_w, new_h), Image.LANCZOS)
        # Crop center back to original size
        left = (new_w - w) // 2
        top  = (new_h - h) // 2
        img  = img.crop((left, top, left + w, top + h))
        return np.array(img)

    return clip.fl(zoom_frame, apply_to=["mask"])


def _make_flash_clip(duration: float = FLASH_DURATION) -> ImageClip:
    """White flash frame for transition."""
    frame = np.ones((H, W, 3), dtype=np.uint8) * 255
    return ImageClip(frame, duration=duration).set_fps(FPS)


def compile_video(media_paths: list[str], voiceover_data: dict, output_stem: str) -> str:
    logger.info("Starting fast-cut video compilation engine...")
    final_path   = config.FINAL_VIDEOS_DIR / f"{output_stem}.mp4"
    total_dur    = voiceover_data["duration_sec"]
    word_timings = voiceover_data["word_timings"]

    if not media_paths:
        raise ValueError("No media paths provided to compile_video.")

    # ── Step 1: Build fast-cut clip sequence with zoom + flash ───────────────
    sequence_clips = []
    current_time   = 0.0

    for path_str in media_paths:
        if current_time >= total_dur:
            break

        clip_path = Path(path_str)
        if not clip_path.exists():
            logger.warning(f"Clip not found: {clip_path}")
            continue

        try:
            raw_clip   = VideoFileClip(str(clip_path), audio=False)
            rem_dur    = total_dur - current_time
            clip_dur   = min(raw_clip.duration, rem_dur, MAX_CLIP_DURATION)

            if clip_dur < 0.3:
                raw_clip.close()
                continue

            clip = raw_clip.subclip(0, clip_dur)

            # ── Crop to portrait 9:16 ────────────────────────────────────────
            cw, ch     = clip.size
            target_r   = W / H
            current_r  = cw / ch
            if current_r > target_r:
                new_w = int(ch * target_r)
                clip  = crop(clip, x_center=cw // 2, width=new_w, height=ch)
            elif current_r < target_r:
                new_h = int(cw / target_r)
                clip  = crop(clip, y_center=ch // 2, width=cw, height=new_h)

            clip = resize(clip, newsize=(W, H))

            # ── Apply Ken Burns zoom ─────────────────────────────────────────
            clip = _apply_zoom_effect(clip)

            sequence_clips.append(clip)
            current_time += clip_dur

            # ── Add flash transition (except after last clip) ────────────────
            if current_time < total_dur:
                sequence_clips.append(_make_flash_clip())
                current_time += FLASH_DURATION

        except Exception as exc:
            logger.warning(f"Clip processing failed ({clip_path.name}): {exc}")
            continue

    if not sequence_clips:
        raise RuntimeError("No clips were processed. Check media files.")

    # ── Step 2: Concatenate all clips + flashes ───────────────────────────────
    video_sequence = concatenate_videoclips(sequence_clips, method="chain")
    video_sequence = video_sequence.subclip(0, min(video_sequence.duration, total_dur))

    # ── Step 3: Attach audio ──────────────────────────────────────────────────
    audio_clip     = AudioFileClip(voiceover_data["audio_path"])
    video_sequence = video_sequence.set_audio(audio_clip)

    # ── Step 4: Caption overlay ───────────────────────────────────────────────
    def make_caption_frame(t):
        frame = _render_caption_frame(t, word_timings)
        return frame[:, :, :3]

    def make_caption_mask(t):
        frame = _render_caption_frame(t, word_timings)
        return frame[:, :, 3] / 255.0

    caption_clip = VideoClip(make_caption_frame, duration=total_dur).set_fps(FPS)
    caption_mask = VideoClip(make_caption_mask, ismask=True, duration=total_dur).set_fps(FPS)
    caption_clip = caption_clip.set_mask(caption_mask)

    # ── Step 5: Vignette overlay ──────────────────────────────────────────────
    def make_vignette_frame(t):
        return _VIGNETTE[:, :, :3]

    def make_vignette_mask(t):
        return _VIGNETTE[:, :, 3] / 255.0

    vignette_clip = VideoClip(make_vignette_frame, duration=total_dur).set_fps(FPS)
    vignette_mask = VideoClip(make_vignette_mask, ismask=True, duration=total_dur).set_fps(FPS)
    vignette_clip = vignette_clip.set_mask(vignette_mask)

    # ── Step 6: Composite final video ─────────────────────────────────────────
    final_video = CompositeVideoClip(
        [video_sequence, vignette_clip, caption_clip],
        size=(W, H),
    )
    final_video = final_video.set_duration(total_dur)

    logger.info(f"Rendering final video → {final_path}")
    final_video.write_videofile(
        str(final_path),
        fps=FPS,
        codec="libx264",
        audio_codec="aac",
        preset="ultrafast",
        threads=4,
        logger=None,
    )

    # ── Cleanup ───────────────────────────────────────────────────────────────
    for obj_name in ("video_sequence", "caption_clip", "caption_mask",
                     "vignette_clip", "vignette_mask", "final_video", "audio_clip"):
        obj = locals().get(obj_name)
        if obj is not None:
            try:
                obj.close()
            except Exception:
                pass
    for c in sequence_clips:
        try:
            c.close()
        except Exception:
            pass

    logger.info(f"✅ Video compiled → {final_path}")
    return str(final_path)
