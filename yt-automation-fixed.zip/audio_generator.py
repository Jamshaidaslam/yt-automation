"""
audio_generator.py — Edge-TTS Male Emotional Voice Engine
AI Dark Realities · Short-Form Video Pipeline
──────────────────────────────────────────────
Changes:
  - Replaced gTTS (female) with edge-tts (Microsoft neural voices)
  - Male voice: en-US-GuyNeural with expressive emotion settings
  - Falls back gracefully if edge-tts fails
  - Accurate word timings from edge-tts boundary events
"""

import asyncio
import json
import logging
import subprocess
import re
from pathlib import Path

import edge_tts
import config

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")

# ── Male Neural Voice Configuration ──────────────────────────────────────────
# en-US-GuyNeural  → deep, dramatic American male
# en-US-TonyNeural → energetic, punchy male
VOICE = "en-US-GuyNeural"

# SSML rate/pitch for dramatic suspense feel
# Rate: faster delivery feels more urgent
# Pitch: slightly lower = more menacing/authoritative
VOICE_RATE  = "+15%"   # slightly faster for urgency
VOICE_PITCH = "-5Hz"   # slightly lower for authority


def generate_voiceover(script: str, output_stem: str) -> dict:
    final_audio_path = config.AUDIO_DIR / f"{output_stem}.mp3"
    timings_path     = config.AUDIO_DIR / f"{output_stem}_timings.json"

    logger.info(f"Synthesising emotional male voiceover via edge-tts [{VOICE}]...")

    word_timings = asyncio.run(
        _generate_edge_tts(script, final_audio_path)
    )

    if not final_audio_path.exists() or final_audio_path.stat().st_size < 1000:
        raise RuntimeError("edge-tts failed to produce audio file.")

    duration_sec = _get_audio_duration_sec(final_audio_path)
    logger.info(f"Audio duration: {duration_sec:.2f}s")

    # If edge-tts gave us word timings use them, else build evenly distributed ones
    if not word_timings:
        logger.warning("No boundary events from edge-tts — using even distribution fallback.")
        word_timings = _build_word_timings_even(script, duration_sec)

    timings_path.write_text(json.dumps(word_timings, indent=2), encoding="utf-8")
    logger.info(f"Word timings saved → {timings_path.name} ({len(word_timings)} words)")

    return {
        "audio_path":   str(final_audio_path),
        "timings_path": str(timings_path),
        "word_timings": word_timings,
        "duration_sec": duration_sec,
    }


async def _generate_edge_tts(script: str, output_path: Path) -> list[dict]:
    """
    Generate audio with edge-tts and collect word boundary events for accurate captions.
    Returns list of {word, start, end} dicts.
    """
    communicate = edge_tts.Communicate(
        text=script,
        voice=VOICE,
        rate=VOICE_RATE,
        pitch=VOICE_PITCH,
    )

    boundary_events = []
    audio_chunks    = []

    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            audio_chunks.append(chunk["data"])
        elif chunk["type"] == "WordBoundary":
            boundary_events.append(chunk)

    # Write raw audio bytes
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "wb") as f:
        for chunk in audio_chunks:
            f.write(chunk)

    logger.info(f"edge-tts: {len(boundary_events)} word boundary events captured.")

    # Convert boundary events → word timings
    word_timings = []
    for i, evt in enumerate(boundary_events):
        start_sec = evt["offset"] / 10_000_000          # 100ns ticks → seconds
        dur_sec   = evt["duration"] / 10_000_000
        end_sec   = start_sec + dur_sec

        # Lookahead: extend end to next word's start for gapless captions
        if i + 1 < len(boundary_events):
            next_start = boundary_events[i + 1]["offset"] / 10_000_000
            end_sec = min(end_sec + 0.05, next_start)

        word = re.sub(r"[^\w''-]", "", evt.get("text", ""))
        if word:
            word_timings.append({
                "word":  word,
                "start": round(start_sec, 3),
                "end":   round(end_sec, 3),
            })

    return word_timings


def _build_word_timings_even(script: str, duration_sec: float) -> list[dict]:
    """Fallback: evenly distribute words across audio duration."""
    words = script.split()
    if not words:
        return []
    per_word = duration_sec / len(words)
    timings, t = [], 0.0
    for word in words:
        clean = re.sub(r"[^\w''-]", "", word)
        if clean:
            timings.append({"word": clean, "start": round(t, 3), "end": round(t + per_word, 3)})
        t += per_word
    return timings


def _get_audio_duration_sec(audio_path: Path) -> float:
    cmd = [
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(audio_path),
    ]
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
    return float(res.stdout.strip())
