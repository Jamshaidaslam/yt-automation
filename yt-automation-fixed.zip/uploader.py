"""
uploader.py — Secure YouTube Upload Engine (COMPLETE FIX)
AI Dark Realities · Short-Form Video Pipeline
──────────────────────────────────────────────
Fixes:
  - Removed broken/incomplete client_secret_ line
  - Now reads YOUTUBE_CLIENT_SECRET and YOUTUBE_TOKEN_JSON from env vars (GitHub Secrets)
  - Proper OAuth2 token refresh logic
  - YouTube Shorts: categoryId=28, made_for_kids=False
  - Tags + description from SEO data
  - upload_all_platforms() returns clean dict always (no crash on missing Instagram)
"""

import json
import logging
import os
import tempfile
from pathlib import Path

from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from googleapiclient.errors import HttpError
from tenacity import retry, stop_after_attempt, wait_exponential

import config

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(levelname)s | %(message)s")


# ══════════════════════════════════════════════════════════════════════════════
# YOUTUBE AUTH — reads from GitHub Secrets (env vars)
# ══════════════════════════════════════════════════════════════════════════════

def _get_youtube_service():
    """
    Build authenticated YouTube API service.
    Reads credentials from environment variables set in GitHub Secrets:
      - YOUTUBE_TOKEN_JSON   : JSON string of the OAuth2 token
      - YOUTUBE_CLIENT_SECRET: JSON string of the client_secret file
    """
    token_json_str  = os.environ.get("YOUTUBE_TOKEN_JSON", "")
    client_secret_str = os.environ.get("YOUTUBE_CLIENT_SECRET", "")

    if not token_json_str:
        raise EnvironmentError(
            "YOUTUBE_TOKEN_JSON secret is missing. "
            "Add it to GitHub Secrets (Settings → Secrets → Actions)."
        )

    token_data = json.loads(token_json_str)
    creds = Credentials(
        token         = token_data.get("token"),
        refresh_token = token_data.get("refresh_token"),
        token_uri     = token_data.get("token_uri", "https://oauth2.googleapis.com/token"),
        client_id     = token_data.get("client_id"),
        client_secret = token_data.get("client_secret"),
        scopes        = config.YOUTUBE_SCOPES,
    )

    # Auto-refresh if expired
    if creds.expired and creds.refresh_token:
        logger.info("Refreshing expired YouTube OAuth2 token...")
        creds.refresh(Request())
        logger.info("Token refreshed successfully.")

    if not creds.valid:
        raise RuntimeError(
            "YouTube credentials are invalid and could not be refreshed. "
            "Re-run the local OAuth flow and update YOUTUBE_TOKEN_JSON secret."
        )

    service = build("youtube", "v3", credentials=creds, cache_discovery=False)
    logger.info("YouTube API service authenticated successfully.")
    return service


# ══════════════════════════════════════════════════════════════════════════════
# YOUTUBE UPLOAD
# ══════════════════════════════════════════════════════════════════════════════

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=2, min=10, max=60),
    reraise=True,
)
def upload_to_youtube(video_path: str, seo: dict) -> dict:
    """
    Upload video to YouTube as a Short.
    Returns dict with video_id and url on success.
    """
    video_file = Path(video_path)
    if not video_file.exists():
        raise FileNotFoundError(f"Video file not found: {video_path}")

    title       = seo.get("title", "AI Dark Reality #Shorts")[:100]
    description = seo.get("description", "")
    hashtags    = seo.get("hashtags", ["#Shorts", "#AI", "#Tech"])

    # Append hashtags to description
    hashtag_str  = " ".join(hashtags)
    full_desc    = f"{description}\n\n{hashtag_str}"

    # Tags list (strip # for YouTube tags)
    tags = [h.lstrip("#") for h in hashtags] + ["Shorts", "AI", "Technology"]

    body = {
        "snippet": {
            "title":       title,
            "description": full_desc,
            "tags":        tags[:30],          # YouTube max 30 tags
            "categoryId":  "28",               # Science & Technology
            "defaultLanguage": "en",
        },
        "status": {
            "privacyStatus":           "public",
            "selfDeclaredMadeForKids": False,
            "madeForKids":             False,
        },
    }

    service = _get_youtube_service()

    logger.info(f"Starting YouTube upload: '{title}' ({video_file.stat().st_size // 1024} KB)")

    media = MediaFileUpload(
        str(video_file),
        mimetype="video/mp4",
        resumable=True,
        chunksize=5 * 1024 * 1024,   # 5 MB chunks
    )

    request  = service.videos().insert(part="snippet,status", body=body, media_body=media)
    response = None

    while response is None:
        status, response = request.next_chunk()
        if status:
            pct = int(status.progress() * 100)
            logger.info(f"Upload progress: {pct}%")

    video_id  = response.get("id", "unknown")
    video_url = f"https://youtube.com/shorts/{video_id}"
    logger.info(f"✅ Uploaded to YouTube → {video_url}")

    return {"platform": "youtube", "video_id": video_id, "url": video_url, "status": "success"}


# ══════════════════════════════════════════════════════════════════════════════
# MULTI-PLATFORM ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

def upload_all_platforms(video_path: str, seo: dict) -> dict:
    """
    Upload to all configured platforms.
    Returns results dict — never crashes the pipeline on individual platform failure.
    """
    results = {}

    # ── YouTube ───────────────────────────────────────────────────────────────
    try:
        results["youtube"] = upload_to_youtube(video_path, seo)
    except EnvironmentError as e:
        logger.error(f"YouTube upload skipped (missing secret): {e}")
        results["youtube"] = {"platform": "youtube", "status": "skipped", "reason": str(e)}
    except HttpError as e:
        logger.error(f"YouTube API error: {e}")
        results["youtube"] = {"platform": "youtube", "status": "failed", "reason": str(e)}
    except Exception as e:
        logger.error(f"YouTube upload failed: {e}")
        results["youtube"] = {"platform": "youtube", "status": "failed", "reason": str(e)}

    # ── Instagram (optional — only if META_ACCESS_TOKEN is set) ───────────────
    meta_token = os.environ.get("META_ACCESS_TOKEN", "")
    if meta_token:
        try:
            results["instagram"] = _upload_instagram_reel(video_path, seo, meta_token)
        except Exception as e:
            logger.warning(f"Instagram upload failed (non-fatal): {e}")
            results["instagram"] = {"platform": "instagram", "status": "failed", "reason": str(e)}
    else:
        logger.info("META_ACCESS_TOKEN not set — skipping Instagram upload.")
        results["instagram"] = {"platform": "instagram", "status": "skipped", "reason": "No token"}

    return results


def _upload_instagram_reel(video_path: str, seo: dict, access_token: str) -> dict:
    """Upload reel to Instagram via Graph API."""
    import requests as req

    account_id = os.environ.get("INSTAGRAM_ACCOUNT_ID", "")
    if not account_id:
        raise EnvironmentError("INSTAGRAM_ACCOUNT_ID not set in GitHub Secrets.")

    caption = seo.get("title", "") + "\n\n" + " ".join(seo.get("hashtags", []))

    # Step 1: Create media container
    # NOTE: Instagram requires a publicly accessible video URL.
    # This requires hosting the video somewhere first (e.g. GitHub Release or S3).
    # For now we log a clear message and return skipped.
    logger.warning(
        "Instagram Reels upload requires a public video URL. "
        "Host the video publicly first, then set VIDEO_PUBLIC_URL env var."
    )
    public_url = os.environ.get("VIDEO_PUBLIC_URL", "")
    if not public_url:
        return {"platform": "instagram", "status": "skipped",
                "reason": "VIDEO_PUBLIC_URL not set — Instagram needs a public video URL."}

    container_url = f"https://graph.facebook.com/v19.0/{account_id}/media"
    r = req.post(container_url, data={
        "media_type":   "REELS",
        "video_url":    public_url,
        "caption":      caption,
        "access_token": access_token,
    }, timeout=30)
    r.raise_for_status()
    container_id = r.json().get("id")

    # Step 2: Publish
    publish_url = f"https://graph.facebook.com/v19.0/{account_id}/media_publish"
    r2 = req.post(publish_url, data={
        "creation_id":  container_id,
        "access_token": access_token,
    }, timeout=30)
    r2.raise_for_status()

    reel_id  = r2.json().get("id", "unknown")
    reel_url = f"https://www.instagram.com/reels/{reel_id}/"
    logger.info(f"✅ Instagram Reel uploaded → {reel_url}")
    return {"platform": "instagram", "status": "success", "reel_id": reel_id, "url": reel_url}
